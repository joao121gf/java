package br.com.alura;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/")
public class AgendamentoEmailApplication extends Application {

}
