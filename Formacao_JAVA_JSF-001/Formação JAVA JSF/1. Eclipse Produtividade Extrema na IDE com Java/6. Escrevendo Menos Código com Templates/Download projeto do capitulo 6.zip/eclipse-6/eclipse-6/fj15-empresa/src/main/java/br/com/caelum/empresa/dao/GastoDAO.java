package br.com.caelum.empresa.dao;

import br.com.caelum.empresa.modelo.Gasto;


public class GastoDAO extends DAO<Gasto> {

	public GastoDAO() {
		super(Gasto.class);
	}

}